#include "mbed.h"
#include "Dht11.h"

//float vref = 4;
float offset = 0;

AnalogIn sensorLT(p17);
Dht11 sensorTP(p18);
AnalogIn sensorEC(p19);
AnalogIn sensorPH(p20);



int main() {
    int gLT;
    float LT, voltCoef, readPH=0, readEC=0, ECcurrent=0,avgEC=0;
    int i = 0;
    //printf("%f", p20.get_reference_voltage);
    //sensorPH.set_reference_voltage(vref);
    while(1) {
        wait(1);
        
        sensorTP.read();
        float tempCoef = 1.0+0.0185*(sensorTP.getCelsius()-25);
        
        readEC = readEC + sensorEC.read();
        
        readPH = readPH + sensorPH.read();
                
        if(i>=10){
            avgEC = readEC*3300/10;
            readEC=0;
            voltCoef = avgEC/tempCoef;
            
            if(voltCoef<=448)
                ECcurrent=6.84*voltCoef-64.32;       //1ms/cm<EC<=3ms/cm
            else if(voltCoef<=1457)
                ECcurrent=6.98*voltCoef-127;        //3ms/cm<EC<=10ms/cm
            else 
                ECcurrent=5.3*voltCoef+2278;        //10ms/cm<EC<20ms/cm
            
            float printEC = ECcurrent;
            
             // Phmetro
             
            float printPH = readPH/10*3.27*1.22*3.5+offset;
            readPH=0;
            
            //sensor de temperatura
            int printTP = sensorTP.getCelsius();
            
            //sensor de luz
            LT = sensorLT.read();
            if(LT<0.5)
                gLT=1;
            else
                gLT=0;
            int printLT = gLT;
            
            printf("{\"temperatura\": %i, \"ph\": %f, \"condutividade\": %f, \"luminosidade\": %i}", printTP, printPH, printEC, printLT);
            printf("\n");
            
            i = 0;
        }

        i++;
    }
}
